export interface Pharmacy {
  id: string;
  name: string;
  address: string;
  isOpen: boolean;
  distance?: string;
  phone?: string;
}