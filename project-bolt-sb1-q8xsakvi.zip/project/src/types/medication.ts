export interface Medication {
  name: string;
  indications: string;
  warnings: string;
  manufacturer: string;
}