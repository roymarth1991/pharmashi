import React from 'react';
import { Layout } from './components/Layout';
import { PhamashApp } from './features/phamash/PhamashApp';

function App() {
  return (
    <Layout>
      <PhamashApp />
    </Layout>
  );
}

export default App;