import { Medication } from '../types/medication';

// Simulated API response because we don't have actual API keys
const MOCK_MEDICATIONS: Record<string, Medication[]> = {
  "ibuprofen": [
    {
      name: "Ibuprofen",
      indications: "For relief of minor aches and pains due to headache, muscular aches, backache, arthritis, the common cold, toothache, and menstrual cramps. Reduces fever.",
      warnings: "May cause stomach bleeding. The risk is higher if you are over 60 years of age, have had stomach ulcers or bleeding problems, take other drugs that may cause stomach bleeding.",
      manufacturer: "Generic Pharmaceuticals Inc."
    }
  ],
  "aspirin": [
    {
      name: "Aspirin",
      indications: "For pain relief, fever reduction, and anti-inflammatory effects. Used for conditions such as headache, toothache, common cold, and arthritis.",
      warnings: "May cause stomach bleeding. Children and teenagers should not use this medicine for chicken pox or flu symptoms before a doctor is consulted. Reye's syndrome, a rare but serious illness, may occur.",
      manufacturer: "Bayer AG"
    }
  ],
  "tylenol": [
    {
      name: "Tylenol (Acetaminophen)",
      indications: "For the temporary relief of minor aches and pains due to headache, muscular aches, backache, minor pain of arthritis, the common cold, toothache, and premenstrual and menstrual cramps. Reduces fever.",
      warnings: "Liver warning: This product contains acetaminophen. Severe liver damage may occur if you take more than the maximum daily amount, with other drugs containing acetaminophen, or if you have 3 or more alcoholic drinks every day while using this product.",
      manufacturer: "Johnson & Johnson"
    }
  ],
  "amoxicillin": [
    {
      name: "Amoxicillin",
      indications: "For treatment of infections caused by bacteria. Used for conditions such as pneumonia, bronchitis, and infections of the ears, nose, throat, urinary tract, and skin.",
      warnings: "May cause allergic reactions in people who are allergic to penicillin. Stop use and get medical help if signs of allergic reaction occur.",
      manufacturer: "GlaxoSmithKline"
    }
  ]
};

export const searchMedication = async (query: string): Promise<Medication[]> => {
  // Simulate network request
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const normalizedQuery = query.toLowerCase().trim();
  
  // Check for exact matches
  if (normalizedQuery in MOCK_MEDICATIONS) {
    return MOCK_MEDICATIONS[normalizedQuery];
  }
  
  // Check for partial matches
  for (const [key, medications] of Object.entries(MOCK_MEDICATIONS)) {
    if (key.includes(normalizedQuery) || normalizedQuery.includes(key)) {
      return medications;
    }
    
    // Check if any medication name contains the query
    for (const medication of medications) {
      if (medication.name.toLowerCase().includes(normalizedQuery)) {
        return [medication];
      }
    }
  }
  
  // In a real app, this would be an API call to OpenFDA
  // Example: const response = await fetch(`https://api.fda.gov/drug/label.json?search=${query}&limit=5`);
  
  return [];
};