import { Pharmacy } from '../types/pharmacy';

// Mock data for nearby pharmacies
const MOCK_PHARMACIES: Pharmacy[] = [
  {
    id: '1',
    name: 'Community Pharmacy',
    address: '123 Main Street, Anytown',
    isOpen: true,
    distance: '0.5',
    phone: '(555) 123-4567'
  },
  {
    id: '2',
    name: 'MediPlus Drugstore',
    address: '456 Oak Avenue, Anytown',
    isOpen: true,
    distance: '0.8',
    phone: '(555) 987-6543'
  },
  {
    id: '3',
    name: 'Health Essentials Pharmacy',
    address: '789 Pine Road, Anytown',
    isOpen: false,
    distance: '1.2',
    phone: '(555) 555-5555'
  },
  {
    id: '4',
    name: 'CarePlus Pharmacy',
    address: '321 Elm Street, Anytown',
    isOpen: true,
    distance: '1.5',
    phone: '(555) 222-3333'
  },
  {
    id: '5',
    name: 'Wellness Pharmacy',
    address: '654 Maple Drive, Anytown',
    isOpen: false,
    distance: '2.1',
    phone: '(555) 777-8888'
  }
];

export const getNearbyPharmacies = async (latitude: number, longitude: number): Promise<Pharmacy[]> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // In a real app, this would be an API call to Google Places API
  // Example: const response = await fetch(`https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${latitude},${longitude}&radius=5000&type=pharmacy&key=${API_KEY}`);
  
  return MOCK_PHARMACIES;
};