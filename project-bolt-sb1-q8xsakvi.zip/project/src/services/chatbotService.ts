// Simulated responses for common medical questions
const RESPONSES: Record<string, string> = {
  "headache": "Headaches can be caused by stress, dehydration, lack of sleep, or tension. For occasional headaches, over-the-counter pain relievers like acetaminophen or ibuprofen may help. Make sure to stay hydrated and get adequate rest. If headaches are severe, persistent, or accompanied by other symptoms, please consult a healthcare professional.",
  
  "cold": "Common cold symptoms include runny nose, congestion, sore throat, and cough. Rest, stay hydrated, and consider over-the-counter medications for symptom relief. Most colds resolve within 7-10 days. If symptoms worsen or persist beyond two weeks, consult a healthcare provider.",
  
  "fever": "Fever is usually a sign that your body is fighting an infection. For adults, a temperature above 100.4°F (38°C) is considered a fever. Rest, stay hydrated, and take acetaminophen or ibuprofen as directed for comfort. Seek medical attention if the fever is higher than 103°F (39.4°C), lasts more than three days, or is accompanied by severe symptoms.",
  
  "medication": "It's important to take medications as prescribed by your healthcare provider. Always read the label for dosage instructions and potential side effects. Don't discontinue prescription medications without consulting your doctor, and inform them of all medications you're taking to avoid interactions.",
  
  "dosage": "Always follow the recommended dosage on the medication label or as prescribed by your healthcare provider. Taking more than the recommended dose can be dangerous and may lead to serious side effects. If you're unsure about the correct dosage, consult a pharmacist or your doctor.",
  
  "side effects": "All medications can have potential side effects. Common ones include nausea, dizziness, or headaches. Read the medication insert for specific information. If you experience severe or unusual side effects, contact your healthcare provider immediately.",
  
  "pregnant": "If you're pregnant or nursing, always consult with your healthcare provider before taking any medication, including over-the-counter products. Many medications can affect your baby's development or pass through breast milk.",
  
  "allergic reaction": "Signs of an allergic reaction may include rash, itching, swelling (especially of the face, tongue, or throat), severe dizziness, or trouble breathing. If you experience these symptoms after taking a medication, seek emergency medical help immediately.",
  
  "prescription": "Prescription medications require a doctor's order. Never share prescriptions with others, even if they have similar symptoms. Always complete the full course of antibiotics as prescribed, even if you start feeling better.",
  
  "ibuprofen": "Ibuprofen is a nonsteroidal anti-inflammatory drug (NSAID) used to reduce fever and treat pain or inflammation. Common brand names include Advil and Motrin. It may cause stomach upset, and should be taken with food. Do not use if you have certain medical conditions like kidney disease or a history of stomach ulcers without consulting your doctor.",
  
  "tylenol": "Tylenol contains acetaminophen and is used for pain relief and fever reduction. Unlike NSAIDs, it doesn't reduce inflammation. Be careful not to exceed the maximum daily dose as this can cause liver damage. Avoid alcohol when taking acetaminophen."
};

export const askMedicalAssistant = async (question: string): Promise<string> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  const normalizedQuestion = question.toLowerCase();
  
  // Check for keyword matches in the question
  for (const [keyword, response] of Object.entries(RESPONSES)) {
    if (normalizedQuestion.includes(keyword)) {
      return response;
    }
  }
  
  // Default response if no keywords match
  return "I understand you have a question about your health. While I can provide general information, I'm not able to provide specific medical advice or diagnosis. For personalized guidance, please consult with a healthcare professional. Is there anything specific about medications or general health information I can help you with?";
  
  // In a real app, this would be an API call to a chatbot service
  // Example: const response = await fetch('https://api.openai.com/v1/chat/completions', {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${API_KEY}` },
  //   body: JSON.stringify({ 
  //     model: 'gpt-3.5-turbo',
  //     messages: [{ role: 'user', content: `Medical question: ${question}` }]
  //   })
  // });
};