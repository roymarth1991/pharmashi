import React, { useState, useEffect } from 'react';
import { MapPin, Loader, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Pharmacy } from '../../types/pharmacy';
import { getNearbyPharmacies } from '../../services/pharmacyService';

export const PharmacyFinder: React.FC = () => {
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);

  const fetchPharmacies = async () => {
    if (!location) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const nearbyPharmacies = await getNearbyPharmacies(location.lat, location.lng);
      setPharmacies(nearbyPharmacies);
    } catch (err) {
      setError('Unable to find nearby pharmacies. Please try again later.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGetLocation = () => {
    setIsLoading(true);
    setError(null);
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation({ lat: latitude, lng: longitude });
        },
        (err) => {
          setError('Unable to get your location. Please enable location services and try again.');
          setIsLoading(false);
          console.error(err);
        }
      );
    } else {
      setError('Geolocation is not supported by your browser.');
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (location) {
      fetchPharmacies();
    }
  }, [location]);

  return (
    <Card>
      <CardHeader 
        title="Nearby Pharmacies" 
        subtitle="Find pharmacies in your area"
      />
      <CardContent>
        {!location && (
          <div className="text-center py-6">
            <MapPin className="h-12 w-12 mx-auto text-blue-600 mb-3" />
            <p className="text-gray-600 mb-4">
              Allow location access to find pharmacies near you
            </p>
            <Button 
              onClick={handleGetLocation} 
              isLoading={isLoading}
            >
              <MapPin className="h-4 w-4 mr-2" />
              Find Nearby Pharmacies
            </Button>
          </div>
        )}

        {error && (
          <div className="p-3 bg-red-50 text-red-700 rounded-md mb-4">
            {error}
          </div>
        )}

        {isLoading && location && (
          <div className="flex items-center justify-center py-12">
            <Loader className="h-8 w-8 animate-spin text-blue-600" />
            <span className="ml-2 text-gray-600">Finding pharmacies near you...</span>
          </div>
        )}

        {pharmacies.length > 0 && (
          <div className="space-y-3 max-h-80 overflow-y-auto pr-2">
            {pharmacies.map((pharmacy, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-3 hover:bg-gray-50 transition-colors">
                <div className="flex items-start">
                  <MapPin className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div className="ml-2">
                    <h3 className="font-medium text-gray-900">{pharmacy.name}</h3>
                    <p className="text-sm text-gray-600">{pharmacy.address}</p>
                    
                    <div className="mt-1 flex items-center">
                      <Clock className="h-4 w-4 text-gray-400 mr-1" />
                      <span className={`text-sm ${pharmacy.isOpen ? 'text-green-600' : 'text-red-600'}`}>
                        {pharmacy.isOpen ? 'Open now' : 'Closed'}
                      </span>
                    </div>
                    
                    {pharmacy.distance && (
                      <p className="text-sm text-gray-500 mt-1">
                        {pharmacy.distance} km away
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};