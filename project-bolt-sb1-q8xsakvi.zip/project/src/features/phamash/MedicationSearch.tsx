import React, { useState } from 'react';
import { Search, Mic } from 'lucide-react';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { Card, CardContent, CardHeader } from '../../components/ui/Card';
import { searchMedication } from '../../services/medicationService';
import { Medication } from '../../types/medication';

export const MedicationSearch: React.FC = () => {
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<Medication[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async () => {
    if (!query.trim()) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const medications = await searchMedication(query);
      setResults(medications);
      if (medications.length === 0) {
        setError('No medications found matching your search. Please try different keywords.');
      }
    } catch (err) {
      setError('An error occurred while searching. Please try again later.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader 
        title="Medication Search" 
        subtitle="Search for medications to learn about their usage, side effects, and more."
      />
      <CardContent>
        <div className="flex gap-2 mb-4">
          <Input
            placeholder="Enter medication name or active ingredient"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          />
          <Button 
            onClick={handleSearch} 
            isLoading={isLoading}
            disabled={isLoading || !query.trim()}
          >
            <Search className="h-4 w-4 mr-2" />
            {isLoading ? 'Searching...' : 'Search'}
          </Button>
          <Button variant="outline">
            <Mic className="h-4 w-4" />
          </Button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 text-red-700 rounded-md mb-4">
            {error}
          </div>
        )}

        {results.length > 0 && (
          <div className="space-y-4">
            {results.map((medication, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4 transition-all hover:shadow-md">
                <h3 className="text-lg font-medium text-blue-800">{medication.name}</h3>
                
                <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Indications</h4>
                    <p className="mt-1 text-gray-700">{medication.indications}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Warnings & Side Effects</h4>
                    <p className="mt-1 text-gray-700">{medication.warnings}</p>
                  </div>
                </div>
                
                <div className="mt-3">
                  <h4 className="text-sm font-medium text-gray-500">Manufacturer</h4>
                  <p className="mt-1 text-gray-700">{medication.manufacturer}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};