import React from 'react';
import { MedicationSearch } from './MedicationSearch';
import { PharmacyFinder } from './PharmacyFinder';
import { MedicalAssistant } from './MedicalAssistant';

export const PhamashApp: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">PHAMASH 1.0</h1>
        <p className="mt-2 text-gray-600 max-w-2xl mx-auto">
          Your medical information assistant. Search for medications, find nearby pharmacies, 
          and get answers to your health questions.
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <MedicationSearch />
          <div className="mt-8">
            <PharmacyFinder />
          </div>
        </div>
        
        <div>
          <MedicalAssistant />
        </div>
      </div>
    </div>
  );
};